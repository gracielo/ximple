package org.ximple.exceptions;

import lombok.Generated;
import org.springframework.http.HttpStatus;
import org.ximple.exceptions.enums.XimpleErrorCodeDefault;
import org.ximple.exceptions.enums.XimpleErrorEnum;

import java.util.HashMap;
import java.util.Map;

@Generated
public class XimpleException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private HttpStatus httpStatus;
    private XimpleErrorEnum code;
    private Object[] params;
    private Map<String, Object> payload;

    public XimpleException(HttpStatus httpStatus, String message) {
        super(message);
        this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        this.code = XimpleErrorCodeDefault.XIMP000;
        this.payload = new HashMap();
        this.httpStatus = httpStatus;
    }

    public XimpleException(HttpStatus httpStatus, String message, XimpleErrorEnum code) {
        super(message);
        this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        this.code = XimpleErrorCodeDefault.XIMP000;
        this.payload = new HashMap();
        this.httpStatus = httpStatus;
        this.code = code;
    }

    public XimpleException(HttpStatus httpStatus, String message, XimpleErrorEnum code, Object... params) {
        super(message);
        this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        this.code = XimpleErrorCodeDefault.XIMP000;
        this.payload = new HashMap();
        this.httpStatus = httpStatus;
        this.code = code;
        this.params = params;
    }

    public XimpleException(HttpStatus httpStatus, RuntimeException exception, XimpleErrorEnum code) {
        super(exception);
        this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        this.code = XimpleErrorCodeDefault.XIMP000;
        this.payload = new HashMap();
        this.httpStatus = httpStatus;
        this.code = code;
    }

    public XimpleException(HttpStatus httpStatus, RuntimeException exception, XimpleErrorEnum code, Object... params) {
        super(exception);
        this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        this.code = XimpleErrorCodeDefault.XIMP000;
        this.payload = new HashMap();
        this.httpStatus = httpStatus;
        this.code = code;
        this.params = params;
    }

    public XimpleException(HttpStatus httpStatus, RuntimeException exception, XimpleErrorEnum code, Map<String, Object> payload, Object... params) {
        super(exception);
        this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        this.code = XimpleErrorCodeDefault.XIMP000;
        this.payload = new HashMap();
        this.httpStatus = httpStatus;
        this.code = code;
        this.params = params;
        this.payload = payload;
    }

    public XimpleException() {
        this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        this.code = XimpleErrorCodeDefault.XIMP000;
        this.payload = new HashMap();
    }

    public HttpStatus getHttpStatus() {
        return this.httpStatus;
    }

    public XimpleErrorEnum getCode() {
        return this.code;
    }

    public Object[] getParams() {
        return this.params;
    }

    public Map<String, Object> getPayload() {
        return this.payload;
    }
}
