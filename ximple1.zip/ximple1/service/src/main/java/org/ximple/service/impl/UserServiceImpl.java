package org.ximple.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.ximple.exceptions.XimpleException;
import org.ximple.model.dao.User;
import org.ximple.model.request.UserRequest;
import org.ximple.model.response.UserInfoResponse;
import org.ximple.repository.UserRepository;
import org.ximple.service.UserService;
import org.ximple.util.converter.UserConverter;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Override
    public UserInfoResponse getUserInfo(Long id) {
        return UserConverter.convertTo(this.getUser(id));
    }

    @Override
    public UserInfoResponse saveUser(UserRequest userRequest) {
        Boolean userExisted = userRepository.findByEmail(userRequest.getEmail()).isEmpty();
        if (userExisted) {
            throw new XimpleException(HttpStatus.CONFLICT, "Email already existed");
        }
        User user = new User();
        user.setEmail(userRequest.getEmail());
        user.setUsername(userRequest.getUsername());
        user.setPassword(userRequest.getPassword());
        user.setLastName(userRequest.getLastName());
        user.setFirstName(userRequest.getFirstName());
        return UserConverter.convertTo(userRepository.save(user));
    }

    @Override
    public User getUser(Long id) {
        var user = userRepository.findById(id);
        if (user.isEmpty()) {
            throw new XimpleException(HttpStatus.NOT_FOUND, "User not founded");
        } else {
            return user.get();
        }
    }
}
