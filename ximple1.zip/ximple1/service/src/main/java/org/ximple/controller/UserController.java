package org.ximple.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.ximple.model.request.BookRequest;
import org.ximple.model.request.UserRequest;
import org.ximple.service.UserPublicService;
import org.ximple.service.UserService;

@Slf4j
@RestController
@RequiredArgsConstructor
public class UserController implements UserPublicService {

    private final UserService userService;

    @Override
    public ResponseEntity<?> getCustomerAccountInfo(Long userId) {
        log.info("Start getting user account infor for user: {}",userId);
        return ResponseEntity.ok(userService.getUserInfo(userId));
    }

    @Override
    public ResponseEntity<?> saveCustomerInfo(UserRequest userRequest) {
        log.info("Adding customer info");
        return ResponseEntity.ok(userService.saveUser(userRequest));
    }
}
