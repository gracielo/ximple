package org.ximple.util.converter;

import org.ximple.model.dao.User;
import org.ximple.model.response.UserInfoResponse;

public class UserConverter {
    public static UserInfoResponse convertTo(User user){
        return UserInfoResponse.builder().userName(user.getUsername())
                .email(user.getEmail()).firstName(user.getFirstName())
                .lastName(user.getLastName()).build();
    }
}
