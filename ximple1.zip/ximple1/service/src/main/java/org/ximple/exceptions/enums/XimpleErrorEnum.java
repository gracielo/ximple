package org.ximple.exceptions.enums;

public interface XimpleErrorEnum {
    String getName();
}
