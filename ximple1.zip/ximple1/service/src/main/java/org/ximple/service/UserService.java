package org.ximple.service;

import org.ximple.model.dao.User;
import org.ximple.model.request.UserRequest;
import org.ximple.model.response.UserInfoResponse;

public interface UserService {

    UserInfoResponse getUserInfo(Long id);

    UserInfoResponse saveUser(UserRequest userRequest);
    User getUser(Long id);


}
