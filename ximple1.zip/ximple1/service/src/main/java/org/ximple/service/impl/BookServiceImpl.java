package org.ximple.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.ximple.exceptions.XimpleException;
import org.ximple.model.dao.Book;
import org.ximple.model.request.BookRequest;
import org.ximple.model.response.BookInfoResponse;
import org.ximple.repository.BookRepository;
import org.ximple.service.BookService;
import org.ximple.util.converter.BookConverter;

@Service
@Slf4j
@RequiredArgsConstructor
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;

    @Override
    public BookInfoResponse getBookInfo(Long id) {
        return BookConverter.convertTo(this.getBook(id));
    }

    @Override
    public BookInfoResponse saveBook(BookRequest bookRequest) {
        Boolean existedIsbnBook = bookRepository.existsByIsbn(bookRequest.getIsbn());
        if(existedIsbnBook){
            throw new XimpleException(HttpStatus.CONFLICT,"ISBN already existed");
        }
        Book book = new Book();
        book.setAuthor(bookRequest.getAuthor());
        book.setIsbn(bookRequest.getIsbn());
        book.setGenre(bookRequest.getGenre());
        book.setDescription(bookRequest.getDescription());
        book.setAvailabilityStatus(bookRequest.getAvailabilityStatus());
        book.setPublicationDate(bookRequest.getPublicationDate());
        return BookConverter.convertTo(bookRepository.save(book));
    }

    @Override
    public BookInfoResponse updateAvailability(Long id,Boolean isAvailable) {
        var optBook = bookRepository.findById(id);
        if(optBook.isEmpty()){
            throw new XimpleException(HttpStatus.NOT_FOUND,"Book Not found");
        }
        return BookConverter.convertTo(optBook.get());
    }

    @Override
    public Book getBook(Long bookId) {
        var book = bookRepository.findById(bookId);
        if(book.isEmpty()){
            throw new XimpleException(HttpStatus.NOT_FOUND,"Book Not found");
        }else {
            return book.get();
        }
    }

    @Override
    public void deleteBook(Long bookId) {
        bookRepository.delete(this.getBook(bookId));
    }
}
