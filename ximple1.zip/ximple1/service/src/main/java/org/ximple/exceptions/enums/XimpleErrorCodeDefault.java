package org.ximple.exceptions.enums;

import lombok.Generated;

@Generated
public enum XimpleErrorCodeDefault implements XimpleErrorEnum{
    XIMP000;

    private XimpleErrorCodeDefault(){

    }
    @Override
    public String getName() {
        return this.name();
    }
}
