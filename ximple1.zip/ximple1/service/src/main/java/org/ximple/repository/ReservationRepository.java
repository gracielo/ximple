package org.ximple.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.ximple.model.dao.Reservation;

import java.util.List;

public interface ReservationRepository extends JpaRepository<Reservation,Long> {
    Boolean existsReservationByBook_BookIdAndUser_UserId(Long bookId, Long userId);
    List<Reservation> findAllByUser_UserId(Long userId);
    List<Reservation> findAllByBook_BookId(Long bookId);
}
