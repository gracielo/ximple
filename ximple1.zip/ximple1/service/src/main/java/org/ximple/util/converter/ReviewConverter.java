package org.ximple.util.converter;

import org.ximple.model.dao.Book;
import org.ximple.model.dao.Review;
import org.ximple.model.dao.User;
import org.ximple.model.response.BookInfoResponse;
import org.ximple.model.response.ReviewInfoResponse;
import org.ximple.model.response.UserReviewsResponse;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReviewConverter {

    public static ReviewInfoResponse convertTo(Review review, User userInfoResponse){
        return  ReviewInfoResponse.builder().rating(review.getRating())
                .review(review.getReviewText()).reviewDate(review.getReviewDate())
                .userName(userInfoResponse.getUsername()).build();
    }

}
