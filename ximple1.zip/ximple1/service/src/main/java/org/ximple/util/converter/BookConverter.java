package org.ximple.util.converter;

import org.ximple.model.dao.Book;
import org.ximple.model.response.BookInfoResponse;

public class BookConverter {

    public static BookInfoResponse convertTo(Book book){
        return BookInfoResponse.builder()
                .title(book.getTitle()).author(book.getAuthor())
                .isbn(book.getIsbn()).publicationDate(book.getPublicationDate())
                .genre(book.getGenre()).description(book.getDescription())
                .availabilityStatus(book.isAvailabilityStatus())
                .build();
    }
}
