package org.ximple.service;

import org.ximple.model.dao.Review;
import org.ximple.model.request.ReviewRequest;
import org.ximple.model.response.BookReviewsResponse;
import org.ximple.model.response.ReviewInfoResponse;

import java.util.List;

public interface ReviewService {

    ReviewInfoResponse getReviewInfo(Long id);
    BookReviewsResponse getAllReviewsByBook(Long bookId);
    ReviewInfoResponse saveReview(ReviewRequest request);
    Review getReview(Long reviewId);
    void deleteReview(Long reviewId);

}
