package org.ximple.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.ximple.exceptions.XimpleException;
import org.ximple.model.dao.Reservation;
import org.ximple.model.request.ReservationRequest;
import org.ximple.model.request.ReturnReservationRequest;
import org.ximple.model.response.ReservationResponse;
import org.ximple.repository.ReservationRepository;
import org.ximple.service.BookService;
import org.ximple.service.ReservationService;
import org.ximple.service.UserService;
import org.ximple.util.converter.BookConverter;
import org.ximple.util.converter.ReservationConverter;
import org.ximple.util.converter.UserConverter;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class ReservationServiceImpl implements ReservationService {

    private final ReservationRepository reservationRepository;
    private final UserService userService;
    private final BookService bookService;
    @Override
    public ReservationResponse getReservationInfo(Long id) {
        var optReservation = reservationRepository.findById(id);
        if(optReservation.isEmpty()){
            throw new XimpleException(HttpStatus.NOT_FOUND,"Reservation not found");
        }
        var reservation = optReservation.get();
        var userInfo = userService.getUserInfo(reservation.getUser().getUserId());
        var bookInfo = bookService.getBookInfo(reservation.getBook().getBookId());
        return ReservationConverter.converTo(reservation,userInfo,bookInfo);
    }

    //Missing logic for discount available number of copies
    @Override
    public ReservationResponse saveReservation(ReservationRequest request) {
        var existedReservation = reservationRepository.existsReservationByBook_BookIdAndUser_UserId(request.getBookId(),request.getUserId());
        if(existedReservation){
            throw new XimpleException(HttpStatus.CONFLICT,"The user \\{request.userId} already have a reservation for the book \\{request.bookId}");
        }
        var user = userService.getUser(request.getUserId());
        var book = bookService.getBook(request.getBookId());
        Reservation reservation = new Reservation();
        reservation.setReservationDate(LocalDate.now());
        reservation.setComments(request.getComments());
        reservation.setStatus(request.getStatus());
        reservation.setBook(book);
        reservation.setUser(user);
        var userInfo = UserConverter.convertTo(user);
        var bookInfo = BookConverter.convertTo(book);
        return ReservationConverter.converTo(reservationRepository.save(reservation),userInfo,bookInfo);
    }

    @Override
    public ReservationResponse updateReserationReturned(ReturnReservationRequest request) {
        var optReservation = reservationRepository.findById(request.getReservationId());
        if(optReservation.isEmpty()){
            throw new XimpleException(HttpStatus.NOT_FOUND,"Reservation not found");
        }
        var reservation = optReservation.get();
        reservation.setReturnDate(request.getReturnDate());
        reservation.setStatus(request.getStatus());
        reservation.setComments(request.getComments());
        var userInfo = userService.getUserInfo(reservation.getUser().getUserId());
        var bookInfo = bookService.getBookInfo(reservation.getBook().getBookId());
        return ReservationConverter.converTo(reservationRepository.save(reservation),userInfo,bookInfo);
    }

    @Override
    public List<ReservationResponse> getAllReservationByUser(Long userId) {
        var reservations = reservationRepository.findAllByUser_UserId(userId);
        List<ReservationResponse> response = reservations.stream().map(r -> ReservationConverter.converTo(r,userService.getUserInfo(r.getUser().getUserId()),
                bookService.getBookInfo(r.getBook().getBookId()))).collect(Collectors.toList());
        return response;
    }

    @Override
    public List<ReservationResponse> getAllReservationByBook(Long bookId) {
        var reservations = reservationRepository.findAllByBook_BookId(bookId);
        List<ReservationResponse> response = reservations.stream().map(r -> ReservationConverter.converTo(r,userService.getUserInfo(r.getUser().getUserId()),
                bookService.getBookInfo(r.getBook().getBookId()))).collect(Collectors.toList());
        return response;
    }
}
