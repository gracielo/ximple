package org.ximple.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.ximple.model.request.BookRequest;
import org.ximple.service.BookPublicService;
import org.ximple.service.BookService;

@Slf4j
@RestController
@RequiredArgsConstructor
public class BookController implements BookPublicService {

    private final BookService bookService;

    @Override
    @Cacheable(value = "books", key = "#id")
    public ResponseEntity<?> getBookInfo(Long id) {
        log.info("Getting book {} info",id);
        return ResponseEntity.ok(bookService.getBookInfo(id));
    }

    @Override
    @CachePut(value = "books", key = "#id")
    public ResponseEntity<?> saveBook(BookRequest bookRequest) {
        log.info("Saving book {}",bookRequest.getTitle());
        return ResponseEntity.ok(bookService.saveBook(bookRequest));
    }

    @Override
    @CachePut(value = "books", key = "#id")
    public ResponseEntity<?> updateBookAvailability(Long id, Boolean isAvailable) {
        log.info("Setting availability {} for book {}",isAvailable,id);
        return ResponseEntity.ok(bookService.updateAvailability(id,isAvailable));
    }

    @Override
    @CacheEvict(value = "books", key = "#id")
    public ResponseEntity<?> deleteBook(Long id) {
        log.info("Deleting book: {}",id);
        bookService.deleteBook(id);
        return ResponseEntity.ok(true);
    }
}
