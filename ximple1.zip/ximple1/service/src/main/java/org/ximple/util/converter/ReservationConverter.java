package org.ximple.util.converter;

import org.ximple.model.dao.Reservation;
import org.ximple.model.response.BookInfoResponse;
import org.ximple.model.response.ReservationResponse;
import org.ximple.model.response.UserInfoResponse;

import java.util.Objects;

public class ReservationConverter {
    public static ReservationResponse converTo(Reservation reservation, UserInfoResponse userInfoResponse, BookInfoResponse bookInfoResponse){
        return ReservationResponse.builder()
                .id(reservation.getReservationId()).user(userInfoResponse)
                .book(bookInfoResponse).status(reservation.getStatus())
                .comments(reservation.getComments()).reservationDate(reservation.getReservationDate())
                .returnDate(Objects.isNull(reservation.getReturnDate()) ? null : reservation.getReturnDate())
                .build();
    }
}
