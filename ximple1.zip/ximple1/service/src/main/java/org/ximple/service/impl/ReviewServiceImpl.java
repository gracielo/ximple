package org.ximple.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.ximple.exceptions.XimpleException;
import org.ximple.model.dao.Review;
import org.ximple.model.request.ReviewRequest;
import org.ximple.model.response.BookReviewsResponse;
import org.ximple.model.response.ReviewInfoResponse;
import org.ximple.repository.ReviewRepository;
import org.ximple.service.BookService;
import org.ximple.service.ReviewService;
import org.ximple.service.UserService;
import org.ximple.util.converter.BookConverter;
import org.ximple.util.converter.ReviewConverter;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepository;
    private final UserService userService;
    private final BookService bookService;

    @Override
    public ReviewInfoResponse getReviewInfo(Long id) {
        var review = this.getReview(id);
        return ReviewConverter.convertTo(review,review.getUser());
    }


    @Override
    public BookReviewsResponse getAllReviewsByBook(Long bookId) {
        var book = bookService.getBook(bookId);
        var reviews = reviewRepository.findAllByBook(book);
        List<ReviewInfoResponse> res = reviews.stream().map(review ->
                ReviewConverter.convertTo(review,review.getUser())).collect(Collectors.toList());
        return BookReviewsResponse.builder().bookInfoResponse(BookConverter.convertTo(book)).reviews(res).build();
    }

    @Override
    public ReviewInfoResponse saveReview(ReviewRequest request) {
        var user = userService.getUser(request.getUserId());
        var book = bookService.getBook(request.getBookId());
        Review review = new Review();
        review.setReviewDate(LocalDate.now());
        review.setUser(user);
        review.setBook(book);
        review.setRating(request.getRating());
        review.setReviewText(request.getReview());

        return ReviewConverter.convertTo(reviewRepository.save(review),user);
    }

    @Override
    public Review getReview(Long reviewId) {
        var review = reviewRepository.findById(reviewId);
        if(review.isEmpty()){
            throw new XimpleException(HttpStatus.NOT_FOUND,"Review not found");
        }
        return review.get();
    }

    @Override
    public void deleteReview(Long reviewId) {
        reviewRepository.delete(this.getReview(reviewId));
    }
}
