package org.ximple.service;

import org.ximple.model.request.ReservationRequest;
import org.ximple.model.request.ReturnReservationRequest;
import org.ximple.model.response.ReservationResponse;

import java.util.List;

public interface ReservationService {
    ReservationResponse getReservationInfo(Long id);
    ReservationResponse saveReservation(ReservationRequest request);
    ReservationResponse updateReserationReturned(ReturnReservationRequest request);
    List<ReservationResponse> getAllReservationByUser(Long userId);
    List<ReservationResponse> getAllReservationByBook(Long bookId);

}
