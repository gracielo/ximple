package org.ximple.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.ximple.model.request.ReviewRequest;
import org.ximple.service.ReviewPublicService;
import org.ximple.service.ReviewService;

@Slf4j
@RestController
@RequiredArgsConstructor
public class ReviewController implements ReviewPublicService {

    private final ReviewService reviewService;

    @Override
    @Cacheable(value = "reviews", key = "#id")
    public ResponseEntity<?> getReviewInfo(Long id) {
        return ResponseEntity.ok(reviewService.getReviewInfo(id));
    }


    @Override
    @Cacheable(value = "reviews", key = "#id")
    public ResponseEntity<?> getBookReviewsInfo(Long bookId) {
        return ResponseEntity.ok(reviewService.getAllReviewsByBook(bookId));
    }

    @Override
    @CachePut(value = "reviews", key = "#id")
    public ResponseEntity<?> saveReview(ReviewRequest request) {
        return ResponseEntity.ok(reviewService.saveReview(request));
    }

    @Override
    @CacheEvict(value = "reviews", key = "#id")
    public ResponseEntity<?> deleteReview(Long id) {
        reviewService.deleteReview(id);
        return ResponseEntity.ok(true);
    }
}
