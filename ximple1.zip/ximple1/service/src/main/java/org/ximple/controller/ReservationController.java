package org.ximple.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.ximple.model.request.ReservationRequest;
import org.ximple.model.request.ReturnReservationRequest;
import org.ximple.service.ReservationPublicService;
import org.ximple.service.ReservationService;

@Slf4j
@RestController
@RequiredArgsConstructor
public class ReservationController implements ReservationPublicService {

    private final ReservationService reservationService;

    @Override
    @Cacheable(value = "reservations", key = "#id")
    public ResponseEntity<?> getReservationInfo(Long id) {
        log.info("getting reservation: {}",id);
        return ResponseEntity.ok(reservationService.getReservationInfo(id));
    }

    @Override
    @Cacheable(value = "reservations", key = "#id")
    public ResponseEntity<?> getUserReservationsInfo(Long userId) {
        return ResponseEntity.ok(reservationService.getAllReservationByUser(userId));
    }

    @Override
    @Cacheable(value = "reservations", key = "#id")
    public ResponseEntity<?> getBookReservationsInfo(Long bookId) {
        return ResponseEntity.ok(reservationService.getAllReservationByBook(bookId));
    }

    @Override
    @CachePut(value = "reservations", key = "#id")
    public ResponseEntity<?> saveReservation(ReservationRequest request) {
        return ResponseEntity.ok(reservationService.saveReservation(request));
    }

    @Override
    @CacheEvict(value = "reservations", key = "#id")
    public ResponseEntity<?> returnBook(ReturnReservationRequest request) {
        return ResponseEntity.ok(reservationService.updateReserationReturned(request));
    }
}
