package org.ximple.service;

import org.ximple.model.dao.Book;
import org.ximple.model.request.BookRequest;
import org.ximple.model.response.BookInfoResponse;

public interface BookService {
    BookInfoResponse getBookInfo(Long id);
    BookInfoResponse saveBook(BookRequest bookRequest);
    BookInfoResponse updateAvailability(Long id,Boolean isAvailable);
    Book getBook(Long bookId);
    void deleteBook(Long bookId);
}
