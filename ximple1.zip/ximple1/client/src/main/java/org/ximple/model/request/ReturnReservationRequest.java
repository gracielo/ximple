package org.ximple.model.request;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ReturnReservationRequest {
    private Long reservationId;
    private LocalDate returnDate;
    private  String status;
    private String comments;
}
