package org.ximple.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.ximple.model.request.ReservationRequest;
import org.ximple.model.request.ReturnReservationRequest;

@FeignClient(name = "ReservationService", url = "${ximple.url.library}")
public interface ReservationPublicService {

    @GetMapping("/api/v1/reservation/info/{id}")
    ResponseEntity<?> getReservationInfo(@PathVariable("id") Long id);
    @GetMapping("/api/v1/reservation/user/{userId}")
    ResponseEntity<?> getUserReservationsInfo(@PathVariable("userId") Long userId);
    @GetMapping("/api/v1/reservation/book/{bookId}")
    ResponseEntity<?> getBookReservationsInfo(@PathVariable("bbokId") Long bookId);

    @PostMapping("/api/v1/reservation/save")
    ResponseEntity<?> saveReservation(@RequestBody ReservationRequest request);

    @PatchMapping("/api/v1/reservation/return")
    ResponseEntity<?> returnBook(@RequestBody ReturnReservationRequest request);

}
