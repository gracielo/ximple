package org.ximple.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.ximple.model.request.BookRequest;

@FeignClient(name = "BookService", url = "${ximple.url.library}")
public interface BookPublicService {

    @GetMapping("/api/v1/book/info/{id}")
    ResponseEntity<?> getBookInfo(@PathVariable("id") Long id);

    @PostMapping("/api/v1/book/save")
    ResponseEntity<?> saveBook(@RequestBody BookRequest bookRequest);

    @PatchMapping("/api/v1/book/update/{id}")
    ResponseEntity<?> updateBookAvailability(@PathVariable("id") Long id, @RequestParam("availability") Boolean isAvailable);

    @DeleteMapping("/api/v1/book/delete/{id}")
    ResponseEntity<?> deleteBook(@PathVariable("id") Long id);


}
