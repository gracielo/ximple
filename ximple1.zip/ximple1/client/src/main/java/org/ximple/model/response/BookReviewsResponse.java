package org.ximple.model.response;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class BookReviewsResponse {
    private BookInfoResponse bookInfoResponse;
    private List<ReviewInfoResponse> reviews;
}
