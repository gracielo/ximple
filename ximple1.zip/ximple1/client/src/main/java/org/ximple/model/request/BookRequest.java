package org.ximple.model.request;

import lombok.Data;

import java.time.LocalDate;

@Data
public class BookRequest {
    private String title;
    private String author;
    private String isbn;
    private LocalDate publicationDate;
    private String genre;
    private String description;
    private Boolean availabilityStatus;
}
