package org.ximple.model.response;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class ReviewInfoResponse {
    private Integer rating;
    private String review;
    private LocalDate reviewDate;
    private String userName;
}
