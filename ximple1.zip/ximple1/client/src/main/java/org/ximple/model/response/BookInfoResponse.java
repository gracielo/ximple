package org.ximple.model.response;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class BookInfoResponse {
    private String title;
    private String author;
    private String isbn;
    private LocalDate publicationDate;
    private String genre;
    private String description;
    private Boolean availabilityStatus;
}
