package org.ximple.model.request;

import lombok.Data;

@Data
public class ReviewRequest {
    private Long bookId;
    private Long userId;
    private Integer rating;
    private String review;
}
