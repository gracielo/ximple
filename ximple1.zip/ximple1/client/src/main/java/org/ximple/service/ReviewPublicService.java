package org.ximple.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.ximple.model.request.ReviewRequest;

@FeignClient(name = "ReviewService", url = "${ximple.url.library}")
public interface ReviewPublicService {

    @GetMapping("/api/v1/review/info/{id}")
    ResponseEntity<?> getReviewInfo(@PathVariable("id") Long id);

    @GetMapping("/api/v1/review/book/{bookId}")
    ResponseEntity<?> getBookReviewsInfo(@PathVariable("bookId") Long bookId);

    @PostMapping("/api/v1/review/save")
    ResponseEntity<?> saveReview(@RequestBody ReviewRequest request);

    @DeleteMapping("/api/v1/review/delete/{id}")
    ResponseEntity<?> deleteReview(@PathVariable("id") Long id);

}
