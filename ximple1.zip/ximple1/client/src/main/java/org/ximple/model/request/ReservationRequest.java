package org.ximple.model.request;

import lombok.Data;

@Data
public class ReservationRequest {
    private Long userId;
    private Long bookId;
    private String status;
    private String comments;
}
